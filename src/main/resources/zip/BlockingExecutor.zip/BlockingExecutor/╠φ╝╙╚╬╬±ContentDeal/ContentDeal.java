package com.jd.app.server.common.content;


import com.alibaba.fastjson.JSON;
import com.jd.app.server.auth.PinHolder;
import com.jd.app.server.client.ClientInfoHolder;
import com.jd.app.server.common.ump.Ump;
import com.jd.app.server.concurrent.BlockingExecutor;
import com.jd.app.server.concurrent.HandleTask;
import com.jd.ump.profiler.CallerInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;


public abstract class ContentDeal<T> {
    protected Logger LOGGER = LoggerFactory.getLogger(getClass());

    private ContentDeal<T> next;

    public final void dealContent(BlockingExecutor executor, DealParam<T> params) {
        try {
            if (isParamsLegal(params)) {// 判断版本号是否合法
                String umpKey = umpPrefix() + getClass().getSimpleName();
                if (timeout() > 0 && executor != null) { // 超时执行
                    runWithTimeOut(executor, params, umpKey);
                    return;
                }

                if (asyn() && executor != null) {// 是否异步执行
                    runAsync(executor, params, umpKey);
                    return;
                }

                CallerInfo info = Ump.methodReg(umpKey);
                try {
                    deal(params);
                } catch (Exception e) { // catch住 不然整个链往外抛异常
                    String paramsStr;
                    try {
                        //多线程时可能抛异常，再捕捉一次
                        paramsStr =  JSON.toJSONString(params);
                    }catch (Exception ex){
                        paramsStr = "";
                        LOGGER.error("顺序content deal Fail, params JSON.toJSONString error",ex);
                    }
                    LOGGER.error("顺序content deal Fail umpKey:{}", umpKey);
                    LOGGER.error("顺序content deal Fail params " + paramsStr);
                    LOGGER.error("Exception:",e);
                    Ump.funcError(info);
                } finally {
                    Ump.methodRegEnd(info);
                }
            }
        } finally {
            if (null != next) {// 责任链处理
                next.dealContent(executor, params);
            }
        }
    }

    protected void notifyCDL(DealParam<T> dealParam) {
    }

    protected boolean waitCDL(DealParam<T> dealParam) {
        return false;
    }

    protected abstract void deal(DealParam<T> params);

    public void setNext(ContentDeal<T> next) {
        this.next = next;
    }

    /**
     * 在fork 子线程之前的逻辑
     *
     * @param params 处理参数
     */
    protected void beforeFork(DealParam<T> params) {
        ClientInfoHolder.setClientInfo(params.getClientInfo());
        PinHolder.setPin(params.getPin());
    }

    /**
     * 子线程结束之后的逻辑
     *
     * @param params 处理参数
     */
    protected void endFork(DealParam<T> params) {
        ClientInfoHolder.removeClientInfo();
        PinHolder.removePin();
    }

    /**
     * fork 子线程运行执行逻辑
     *
     * @param params 执行参数
     * @param umpKey umpKey
     */
    private void runAsync(BlockingExecutor executor, final DealParam<T> params, final String umpKey) {
        executor.add(new HandleTask() {
            @Override
            public void execute() {
                CallerInfo info = null;
                beforeFork(params);
                try {
                    info = Ump.methodReg(umpKey);
                    if (waitCDL(params)) return;
                    deal(params);
                } catch (Exception e) {
                    String paramsStr;
                    try {
                        paramsStr =  JSON.toJSONString(params);
                    }catch (Exception ex){
                        paramsStr = "";
                        LOGGER.error("runAsync content deal Fail, params JSON.toJSONString error",ex);
                    }
                    LOGGER.error("runAsync content deal Fail umpKey:{}", umpKey);
                    LOGGER.error("runAsync content deal Fail params " + paramsStr);
                    LOGGER.error("runAsync content deal Fail", e);
                    Ump.funcError(info);
                } finally {
                    notifyCDL(params); //释放锁，以防其他线程一直等待，影响接口性能
                    Ump.methodRegEnd(info);
                    endFork(params);
                }
            }
        });
    }

    /**
     * 绑定超时时间运行
     *
     * @param params 参数
     * @param umpKey umpKey
     */
    private void runWithTimeOut(final BlockingExecutor executor, final DealParam<T> params, String umpKey) {
        CallerInfo info = Ump.methodReg(umpKey);
        Future<?> task = null;
        try {
            task = executor.getExecutorPool().submit(new Runnable() {
                @Override
                public void run() {
                    beforeFork(params);
                    try {
                        deal(params);
                    } finally {
                        endFork(params);
                    }
                }
            });
            task.get(timeout(), TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            String paramsStr;
            try {
                paramsStr =  JSON.toJSONString(params);
            }catch (Exception ex){
                paramsStr = "";
                LOGGER.error("runAsync content deal Fail, params JSON.toJSONString error",ex);
            }
            LOGGER.error("deal TimeOut params " + paramsStr);
            LOGGER.error("deal TimeOut :{}", umpKey, e);
            Ump.funcError(info);
            // 如果是超时则取消任务
            if (task != null && !task.isCancelled()) {
                task.cancel(true);
            }
        } finally {
            Ump.methodRegEnd(info);
        }
    }

    /**
     * 参数是否合法
     *
     * @param params 运行参数
     * @return 是否合法
     */
    protected boolean isParamsLegal(DealParam<T> params) {
        return true;
    }

    /**
     * 是否异步执行
     *
     * @return 否
     */
    protected boolean asyn() {
        return true;
    }

    /**
     * 是否设置最大运行超时时间
     *
     * 0表示不设置超时运行
     *
     * @return milliseconds 超时时间
     */
    protected long timeout() {
        return 0L;
    }

    /**
     * umpKey的前缀
     *
     * @return 请追
     */
    protected String umpPrefix() {
        return "discoverysoa.service.ContentDeal.";
    }
}