package com.jd.app.server.common.content;

import com.jd.app.server.client.ClientInfo;
import com.jd.common.web.result.Result;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;


public class DealParam<T> {
	private T content;
	private String pin;
	private Map<String, Object> params;
	private ClientInfo clientInfo;
	private Result result;
	private String jumpChannel;
	protected Map<Class, List<CountDownLatch>> notify;
	protected Map<Class, CountDownLatch> wait;
	List<String> topLives;//置顶的直播间id
	List<String> whiteListLives;//白名单直播间id
	public DealParam() {
	}

	public DealParam(T content, String pin, ClientInfo clientInfo) {
		this.content = content;
		this.pin = pin;
		this.clientInfo = clientInfo;
	}

	public DealParam(T content, Map<String, Object> params, String pin, ClientInfo clientInfo) {
		super();
		this.content = content;
		this.pin = pin;
		this.params = params;
		this.clientInfo = clientInfo;
	}

	public DealParam(T content, Map<String, Object> params, String pin, ClientInfo clientInfo, Result result) {
		super();
		this.content = content;
		this.pin = pin;
		this.params = params;
		this.clientInfo = clientInfo;
		this.result = result;
	}
	
	public Object getParam(String key) {
	    Object rs = null;
	    if (params != null) {
	        rs = params.get(key);
	    }
	    return rs;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void putParams(String key, Object object) {
		if (params == null)
			params = new HashMap<String, Object>();

		params.put(key, object);
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public T getContent() {
		return content;
	}

	public void setContent(T content) {
		this.content = content;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public ClientInfo getClientInfo() {
		return clientInfo;
	}

	public void setClientInfo(ClientInfo clientInfo) {
		this.clientInfo = clientInfo;
	}

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public String getJumpChannel() {
        return jumpChannel;
    }

    public void setJumpChannel(String jumpChannel) {
        this.jumpChannel = jumpChannel;
    }

	public Map<Class, List<CountDownLatch>> getNotify() {
		return this.notify;
	}

	public void setNotify(Map<Class, List<CountDownLatch>> notify) {
		this.notify = notify;
	}

	public Map<Class, CountDownLatch> getWait() {
		return this.wait;
	}

	public void setWait(Map<Class, CountDownLatch> wait) {
		this.wait = wait;
	}

	public List<String> getTopLives() {
		return topLives;
	}

	public void setTopLives(List<String> topLives) {
		this.topLives = topLives;
	}

	public List<String> getWhiteListLives() {
		return whiteListLives;
	}

	public void setWhiteListLives(List<String> whiteListLives) {
		this.whiteListLives = whiteListLives;
	}

}
