package com.jd.app.server.concurrent;

public interface HandleTask {

	void execute();
}
