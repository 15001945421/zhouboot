package com.jd.app.server.concurrent;

import java.util.Collection;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;

import lombok.extern.slf4j.Slf4j;

public class BlockingExecutor {

	private final ThreadPoolExecutor executorPool;

	private final Sync sync = new Sync();

	private AtomicBoolean isRun = new AtomicBoolean(false);

	private BlockingDeque<Runnable> runners = new LinkedBlockingDeque<Runnable>();

	public BlockingExecutor(ThreadPoolExecutor executorPool) {
		this.executorPool = executorPool;
	}

	private static class Sync extends AbstractQueuedSynchronizer {
		private static final long serialVersionUID = 1429449388426241486L;

		Sync() {
		}

		void setCount(int count) {
			setState(count);
		}

		protected int tryAcquireShared(int acquires) {
			return (getState() == 0) ? 1 : -1;
		}

		protected boolean tryReleaseShared(int releases) {
			while (true) {
				int c = getState();
				if (c == 0)
					return false;
				int nextc = c - 1;
				if (compareAndSetState(c, nextc))
					return nextc == 0;
			}
		}
	}

	private class ConcurrentRunner implements Runnable {
		final HandleTask handler;

		ConcurrentRunner(HandleTask handler) {
			this.handler = handler;
		}

		public void run() {
			try {
				handler.execute();
			} finally {
				sync.releaseShared(1);
			}
		}

	}

	private void addRunnable(final HandleTask handler) {
		runners.add(new ConcurrentRunner(handler));
	}

	public void add(HandleTask... handlers) {
		if (isRun.get())
			throw new RuntimeException("already running, can't add!");

		if (null != handlers && handlers.length > 0) {
			for (HandleTask handler : handlers) {
				addRunnable(handler);
			}
		}
	}

	public void add(Collection<? extends HandleTask> handlers) {
		if (isRun.get())
			throw new RuntimeException("already running, can't add!");

		if (null != handlers && handlers.size() > 0) {
			for (HandleTask handler : handlers) {
				addRunnable(handler);
			}
		}
	}

	private boolean canExecute() {
		return runners.size() > 0;
	}

	public void execute() throws InterruptedException {
		if (canExecute()) {
			if (isRun.compareAndSet(false, true)) {
				sync.setCount(runners.size());
				for (Runnable runnable : runners) {
					executorPool.execute(runnable);
				}
				sync.acquireSharedInterruptibly(1);
			}
		}
	}

	public boolean execute(long timeout, TimeUnit unit) throws InterruptedException {
		if (canExecute()) {
			if (isRun.compareAndSet(false, true)) {
				sync.setCount(runners.size());
				for (Runnable runnable : runners) {
					executorPool.execute(runnable);
				}
				return sync.tryAcquireSharedNanos(1, unit.toNanos(timeout));
			}
		}
		return false;
	}

	public ThreadPoolExecutor getExecutorPool() {
		return executorPool;
	}
}
