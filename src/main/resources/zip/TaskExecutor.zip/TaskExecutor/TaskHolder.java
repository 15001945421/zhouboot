package com.jd.app.server.manager.discovery.live.concurrent;

/**
 * Created by zhouhonglin on 2019/4/3.
 */
public interface TaskHolder {
}
