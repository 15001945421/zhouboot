package com.jd.app.server.manager.discovery.live.concurrent;

/**
 * Created by zhouhonglin on 2019/1/15.
 */

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Invocation {

    private Object target;
    private Method method;
    private String umpKey;
    private String availConfigKey;
    private ClientEnum client;
    private String clientVersion;
    private String maxClientVersion;
    private int order;

    public Invocation(Object target, Method method) {
        this.target = target;
        this.method = method;
    }

    public String getUmpKey() {
        return umpKey;
    }

    public void setUmpKey(String umpKey) {
        this.umpKey = umpKey;
    }

    public String getAvailConfigKey() {
        return availConfigKey;
    }

    public void setAvailConfigKey(String availConfigKey) {
        this.availConfigKey = availConfigKey;
    }

    public Object proceed(Object[] args) throws InvocationTargetException, IllegalAccessException {
        return method.invoke(target, args);
    }

    public Object getTarget() {
        return target;
    }

    public Method getMethod() {
        return method;
    }

    public ClientEnum getClient() {
        return client;
    }

    public void setClient(ClientEnum client) {
        this.client = client;
    }

    public String getClientVersion() {
        return clientVersion;
    }

    public void setClientVersion(String clientVersion) {
        this.clientVersion = clientVersion;
    }

    public String getMaxClientVersion() {
        return maxClientVersion;
    }

    public void setMaxClientVersion(String maxClientVersion) {
        this.maxClientVersion = maxClientVersion;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }
}
