package com.jd.app.server.manager.discovery.live.concurrent;

import com.jd.app.server.client.ClientInfo;
import com.jd.common.web.result.Result;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by zhouhonglin on 2019/1/15.
 */
public class TaskContext<T> {
    private T content;
    private String pin;
    private Map<String, Object> params;
    private ClientInfo clientInfo;
    private Result result;
    private String jumpChannel;

    public TaskContext() {
    }

    public TaskContext(T content, String pin, Map<String, Object> params, ClientInfo clientInfo, Result result) {
        this.content = content;
        this.pin = pin;
        this.params = params;
        this.clientInfo = clientInfo;
        this.result = result;
    }

    public T getContent() {
        return content;
    }

    public void setContent(T content) {
        this.content = content;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    public ClientInfo getClientInfo() {
        return clientInfo;
    }

    public void setClientInfo(ClientInfo clientInfo) {
        this.clientInfo = clientInfo;
    }

    public Result getResult() {
        return result;
    }

    public String getJumpChannel() {
        return jumpChannel;
    }

    public void setJumpChannel(String jumpChannel) {
        this.jumpChannel = jumpChannel;
    }
}
