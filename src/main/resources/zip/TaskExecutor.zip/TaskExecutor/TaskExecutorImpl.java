package com.jd.app.server.manager.discovery.live.concurrent.impl;


import com.google.common.collect.Lists;

import com.jd.app.server.auth.PinHolder;
import com.jd.app.server.client.ClientInfo;
import com.jd.app.server.client.ClientInfoHolder;
import com.jd.app.server.common.ump.Ump;
import com.jd.app.server.domain.discovery.JumpGenrator;
import com.jd.app.server.manager.availconfig.AvailConfigManger;
import com.jd.app.server.manager.discovery.live.concurrent.ConcurrentTask;
import com.jd.app.server.manager.discovery.live.concurrent.Invocation;
import com.jd.app.server.manager.discovery.live.concurrent.TaskContext;
import com.jd.app.server.manager.discovery.live.concurrent.TaskExecuteException;
import com.jd.app.server.manager.discovery.live.concurrent.TaskExecutor;
import com.jd.app.server.manager.discovery.live.concurrent.TaskHolder;
import com.jd.app.server.manager.discovery.live.concurrent.TaskTypeEnum;
import com.jd.app.server.util.ClientVersionUtil;
import com.jd.app.server.util.DiscoveryStringUtils;
import com.jd.ump.profiler.CallerInfo;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by zhouhonglin on 2019/1/14.
 */
public class TaskExecutorImpl implements TaskExecutor {

    protected Logger LOGGER = LoggerFactory.getLogger(getClass());

    static final private Map<Class, Map<String, List<Invocation>>> cacheMethodMap = new ConcurrentHashMap<>();

    static private final String beforeTaskKey = "beforeTask";
    static private final String ConcurrentTaskKey = "concurrentTask";
    static private final String afterTaskKey = "afterTask";

    @Autowired
    private AvailConfigManger availConfigManager;

    private List<Map<String, List<Invocation>>> resolveTasks(List<TaskHolder> taskHolders) {
        if (CollectionUtils.isEmpty(taskHolders)) {
            throw new TaskExecuteException("taskHolders can not be empty");
        }
        List<Map<String, List<Invocation>>> list = new ArrayList<>();
        for (TaskHolder holder : taskHolders) {
            Class holderClass = holder.getClass();
            Map<String, List<Invocation>> map = cacheMethodMap.get(holderClass);
            if (map == null) {
                map = new HashMap<>();
                Method[] methods = holderClass.getDeclaredMethods();
                for (Method method : methods) {
                    if (method.isAnnotationPresent(ConcurrentTask.class)) {
                        if (!validParameter(method)) {
                            throw new TaskExecuteException("Task Method parameterType must be TaskContext");
                        }
                        ConcurrentTask annotation = AnnotationUtils.findAnnotation(method, ConcurrentTask.class);
                        TaskTypeEnum taskType = annotation.taskType();
                        String umpKey = annotation.umpKey();
                        if (StringUtils.isBlank(umpKey)) {
                            umpKey = DiscoveryStringUtils.join(".", umpPrefix(), holderClass.getSimpleName(), method.getName());
                        }
                        String availConfigKey = annotation.availConfigKey();
                        if (StringUtils.isBlank(availConfigKey)) {
                            availConfigKey = DiscoveryStringUtils.join(".", availConfigPrefix(), holderClass.getSimpleName(), method.getName());
                        }
                        Invocation invocation = new Invocation(holder, method);
                        invocation.setAvailConfigKey(availConfigKey);
                        invocation.setUmpKey(umpKey);
                        invocation.setClient(annotation.client());
                        invocation.setClientVersion(annotation.clientVersion());
                        invocation.setMaxClientVersion(annotation.maxClientVersion());
                        invocation.setOrder(annotation.order());
                        if (TaskTypeEnum.BEFORE.equals(taskType)) {
                            if (method.getReturnType().equals(boolean.class)) {
                                putInvocation(map, invocation, beforeTaskKey);
                            } else {
                                throw new TaskExecuteException("BeforeTask ReturnType must be boolean");
                            }
                        } else if (TaskTypeEnum.CONCURRENT.equals(taskType)) {
                            putInvocation(map, invocation, ConcurrentTaskKey);
                        } else if (TaskTypeEnum.AFTER.equals(taskType)) {
                            putInvocation(map, invocation, afterTaskKey);
                        }
                    }
                }
                cacheMethodMap.put(holderClass, map);
            }
            list.add(map);
        }
        return list;
    }

    private void putInvocation(Map<String, List<Invocation>> map, Invocation invo, String key) {
        List<Invocation> Invocations = map.get(key);
        if (Invocations == null) {
            Invocations = new ArrayList<>();
            map.put(key, Invocations);
        }
        Invocations.add(invo);
    }


    private boolean validParameter(Method method) {
        Class[] parameterTypes = method.getParameterTypes();
        return parameterTypes.length == 1 && parameterTypes[0].equals(TaskContext.class);
    }

    @Override
    public void execute(final TaskContext context, List<TaskHolder> taskHolders, ThreadPoolExecutor executorPool) {

        List<Map<String, List<Invocation>>> allTask = this.resolveTasks(taskHolders);
        if (CollectionUtils.isEmpty(allTask))
            return;

        if (executorPool == null) {
            throw new TaskExecuteException("ThreadPool can not be null");
        }
        for (Map<String, List<Invocation>> taskMap : allTask) {
            List<Invocation> beforeTasks = taskMap.get(beforeTaskKey);
            boolean result = true;
            if (CollectionUtils.isNotEmpty(beforeTasks)) {
                orderTaskList(beforeTasks);
                for (Invocation invocation : beforeTasks) {
                    result = runTask(context, invocation);
                    if (!result) {
                        LOGGER.error("beforeTask failed: {}.{}", invocation.getTarget().getClass().getName(), invocation.getMethod().getName());
                        break;
                    }
                }
            }
            if (!result) continue;

            List<Invocation> concurrentTasks = taskMap.get(ConcurrentTaskKey);
            if (CollectionUtils.isNotEmpty(concurrentTasks)) {
                final CountDownLatch latch = new CountDownLatch(concurrentTasks.size());
                for (final Invocation task : concurrentTasks) {
                    executorPool.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                beforeFork(context);
                                runTask(context, task);
                            } finally {
                                latch.countDown();
                                endFork(context);
                            }
                        }
                    });
                }
                try {
                    latch.await(1, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            List<Invocation> afterTasks = taskMap.get(afterTaskKey);
            if (CollectionUtils.isNotEmpty(afterTasks)) {
                orderTaskList(afterTasks);
                for (Invocation invocation : afterTasks) {
                    runTask(context, invocation);
                }
            }
        }
    }

    @Override
    public void execute(TaskContext context, TaskHolder taskHolder, ThreadPoolExecutor executorPool) {
        this.execute(context, Lists.newArrayList(taskHolder), executorPool);
    }

    private void orderTaskList(List<Invocation> tasks) {
        if (CollectionUtils.isEmpty(tasks)) return;
        Collections.sort(tasks, new Comparator<Invocation>() {
            @Override
            public int compare(Invocation o1, Invocation o2) {
                return o1.getOrder() - o2.getOrder();
            }
        });
    }

    private boolean runTask(TaskContext context, Invocation task) {
        String umpKey = task.getUmpKey();

        boolean result = true;
        if (taskValid(context, task)) {
            CallerInfo info = Ump.methodReg(umpKey);
            try {
                Object returnVale = task.proceed(new Object[]{context});
                if (returnVale != null && returnVale.getClass().equals(Boolean.class)) {
                    result = (boolean) returnVale;
                }
                LOGGER.info("ConcurrentTask:{} run success result:{}", task.getMethod().getName(), result);
            } catch (Exception e) {
                LOGGER.error("ConcurrentTask umpKey:{}", umpKey);
                LOGGER.error("ConcurrentTask Exception message:{}", e.getMessage());
                LOGGER.error("ConcurrentTask Exception", e);
                result = false;
                Ump.funcError(info);
            } finally {
                Ump.methodRegEnd(info);
            }

        }
        return result;
    }


    private boolean taskValid(TaskContext context, Invocation task) {
        String availConfigKey = task.getAvailConfigKey();
        boolean enable = availConfigManager.getAvailConfigBool(availConfigKey, true);
        ClientInfo clientInfo = context.getClientInfo();
        boolean validClient = true;
        switch (task.getClient()) {
            case android:
                validClient = ClientVersionUtil.isAndroidClient(clientInfo);
                break;
            case apple:
                validClient = ClientVersionUtil.isIPhoneClient(clientInfo);
                break;
            case wh5:
                validClient = ClientVersionUtil.isH5Client(clientInfo);
                break;
            case pc:
                validClient = clientInfo != null && clientInfo.getClient().equalsIgnoreCase("pc");
                break;
            case phone:
                validClient = ClientVersionUtil.isPhoneApp(clientInfo);
                break;
            case all:
                validClient = true;
        }
        boolean validVersion = true;
        //客户端才判断版本
        if (validVersion && ClientVersionUtil.isPhoneApp(clientInfo) && StringUtils.isNotBlank(task.getClientVersion())) {
            validVersion = ClientVersionUtil.leftLargerOrEqual(clientInfo.getClientVersion(), task.getClientVersion());
        }
        if (validVersion && ClientVersionUtil.isPhoneApp(clientInfo) && StringUtils.isNotBlank(task.getMaxClientVersion())) {
            validVersion = ClientVersionUtil.leftLessThan(clientInfo.getClientVersion(), task.getMaxClientVersion());
        }
        return enable && validClient && validVersion;
    }

    protected void beforeFork(TaskContext context) {
        ClientInfoHolder.setClientInfo(context.getClientInfo());
        PinHolder.setPin(context.getPin());
        JumpGenrator.setJumpChannel(context.getJumpChannel());
    }

    protected void endFork(TaskContext context) {
        ClientInfoHolder.removeClientInfo();
        PinHolder.removePin();
        JumpGenrator.clearJumpChannel();
    }

    protected String umpPrefix() {
        return "discoverysoa.service";
    }

    protected String availConfigPrefix() {
        return "discoverysoa.availconfig";
    }
}
