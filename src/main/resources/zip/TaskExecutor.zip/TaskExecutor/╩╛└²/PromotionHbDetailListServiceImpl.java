package com.jd.app.server.service.promotionhb.v2;

import com.google.common.base.Joiner;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.jd.app.server.client.ClientInfo;
import com.jd.app.server.content.tools.limitclean.limit.SampleAndLimit;
import com.jd.app.server.domain.discovery.JumpGenrator;
import com.jd.app.server.domain.promotionhb.v2.PromotionHbActivityConstant;
import com.jd.app.server.domain.promotionhb.v2.PromotionHbDetailListContext;
import com.jd.app.server.domain.promotionhb.v2.VideoHbDetailInfo;
import com.jd.app.server.manager.availconfig.AvailConfigManger;
import com.jd.app.server.manager.discovery.live.concurrent.TaskContext;
import com.jd.app.server.manager.discovery.live.concurrent.TaskExecutor;
import com.jd.app.server.manager.discovery.live.concurrent.TaskHolder;
import com.jd.app.server.util.DeviceIdUtil;
import com.jd.app.server.util.ResultUtils;
import com.jd.common.web.result.Result;
import com.jd.jim.cli.Cluster;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author wuchuanquan
 * @date 2019/6/13 14:08
 */
@Service("promotionHbDetailListService")
public class PromotionHbDetailListServiceImpl implements PromotionHbDetailListService {

    @Autowired
    private TaskExecutor taskExecutor;

    @Autowired
    private TaskHolder promotionHbDetailListTaskHolder;

    @Autowired
    private ThreadPoolExecutor commonTaskThreadPool;

    @Autowired
    protected AvailConfigManger availConfigManager;

    @Autowired
    private Cluster promotionHbClient;

    @Autowired
    private PromotionHbDetailListTask promotionHbDetailListTask;

    private int pageSize = 5;

    @Override
    @SampleAndLimit(limitMax = 200)
    public void getPromotionHbDetailList(Map<String, Object> bodyParam, ClientInfo clientInfo, Result result) {

        String pin = MapUtils.getString(bodyParam, "pin", "");
        String offSet = MapUtils.getString(bodyParam, "offSet", "");
        String refreshActivityId = MapUtils.getString(bodyParam, "refreshActivityId", "");

        if (StringUtils.isEmpty(offSet) || StringUtils.isNotEmpty(refreshActivityId)) {
            refreshDetailList(bodyParam, clientInfo, result);
        } else {
            String detailList = null;
            if (StringUtils.isEmpty(pin)) {
                String uuid = DeviceIdUtil.getDeviceId(clientInfo);
                String key = Joiner.on("_").join(PromotionHbActivityConstant.USER_ACTIVITY_DETAIL_LIST_PREFIX, uuid);
                detailList = promotionHbClient.get(key);
            } else {
                String key = Joiner.on("_").join(PromotionHbActivityConstant.USER_ACTIVITY_DETAIL_LIST_PREFIX, pin);
                detailList = promotionHbClient.get(key);
            }

            if (StringUtils.isEmpty(detailList)) {
                refreshDetailList(bodyParam, clientInfo, result);
            } else {
                TaskContext<PromotionHbDetailListContext> cacheContext = JSON.parseObject(detailList, new TypeReference<TaskContext<PromotionHbDetailListContext>>() {
                });
                if (null == cacheContext) {
                    refreshDetailList(bodyParam, clientInfo, result);
                } else {
                    promotionHbDetailListTask.preHandle(cacheContext);
                    promotionHbDetailListTask.getHongbaoInfo(cacheContext);
                    promotionHbDetailListTask.checkOutOfAnswerLimit(cacheContext);
                    PromotionHbDetailListContext pdlc = cacheContext.getContent();
                    getPagingDetailList(result, pdlc, offSet);
                }
            }
        }
    }

    private void refreshDetailList(Map<String, Object> bodyParam, ClientInfo clientInfo, Result result) {
        String pin = MapUtils.getString(bodyParam, "pin", "");
        PromotionHbDetailListContext pdlc = new PromotionHbDetailListContext();
        TaskContext<PromotionHbDetailListContext> taskContext = new TaskContext<>(pdlc, pin, bodyParam, clientInfo, result);
        taskContext.setJumpChannel(JumpGenrator.getJumpChannel());
        taskExecutor.execute(taskContext, promotionHbDetailListTaskHolder, commonTaskThreadPool);
        getFirstPage(pdlc);

        filterDataModel(result, pdlc);
    }

    private void getPagingDetailList(Result result, PromotionHbDetailListContext pdlc, String offSet) {

        List<VideoHbDetailInfo> list = pdlc.getList();
        int index = 0;
        boolean haveOffSet = false;
        for (VideoHbDetailInfo detailInfo : list) {
            index++;
            if (detailInfo.getActivityId().equalsIgnoreCase(offSet)) {
                haveOffSet = true;
                break;
            }
        }

        if (haveOffSet) {
            if (index >= pdlc.getList().size()) {
                pdlc.setList(new ArrayList<VideoHbDetailInfo>());
                pdlc.setOffSet(offSet);
            } else {
                if (index + pageSize < pdlc.getList().size()) {
                    List<VideoHbDetailInfo> videoHbDetailInfoList = pdlc.getList().subList(index, index + pageSize);
                    pdlc.setList(videoHbDetailInfoList);
                } else {
                    List<VideoHbDetailInfo> videoHbDetailInfoList = pdlc.getList().subList(index, pdlc.getList().size());
                    pdlc.setList(videoHbDetailInfoList);
                }
                pdlc.setOffSet(pdlc.getList().get(pdlc.getList().size() - 1).getActivityId());
            }
        } else {
            getFirstPage(pdlc);
        }

        filterDataModel(result, pdlc);
    }

    private void filterDataModel(Result result, PromotionHbDetailListContext pdlc) {
        ResultUtils.buildSuccessResult(result);
        pdlc.setValidActivityInfoList(null);
        List<VideoHbDetailInfo> videoHbDetailInfoList = pdlc.getList();
        if (null != videoHbDetailInfoList) {
            Iterator<VideoHbDetailInfo> infoIterator = videoHbDetailInfoList.iterator();
            while (infoIterator.hasNext()) {
                VideoHbDetailInfo detailInfo = infoIterator.next();
                detailInfo.setSkuIds(null);
                detailInfo.setPromotionHbActivityInfo(null);
            }
        }
        result.addDefaultModel("data", pdlc);
    }

    private void getFirstPage(PromotionHbDetailListContext pdlc) {
        if (pdlc.getList().size() > pageSize) {
            List<VideoHbDetailInfo> videoHbDetailInfoList = pdlc.getList().subList(0, pageSize);
            pdlc.setList(videoHbDetailInfoList);
            pdlc.setOffSet(pdlc.getList().get(pdlc.getList().size() - 1).getActivityId());
        } else if (pdlc.getList().size() > 0) {
            pdlc.setOffSet(pdlc.getList().get(pdlc.getList().size() - 1).getActivityId());
        } else {
            //没有有效数据
            pdlc.setOffSet("");
        }
    }

}
