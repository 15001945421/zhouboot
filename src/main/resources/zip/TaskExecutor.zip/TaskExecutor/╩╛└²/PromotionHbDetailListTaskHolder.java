package com.jd.app.server.service.promotionhb.v2;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.parser.ParserConfig;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.common.base.Joiner;
import com.jd.app.server.client.ClientInfo;
import com.jd.app.server.constants.PromotionHbConstants;
import com.jd.app.server.constants.VideoHbConfigKeyConstants;
import com.jd.app.server.domain.discovery.JumpGenrator;
import com.jd.app.server.domain.discovery.author.vo.AuthorInfoDIY;
import com.jd.app.server.domain.discovery.shareInfo.ShareInfo;
import com.jd.app.server.domain.discovery.wareInfo.ShopInfoDIY;
import com.jd.app.server.domain.enums.video.VideoBusinessSwitchEnums;
import com.jd.app.server.domain.promotionhb.v2.*;
import com.jd.app.server.manager.availconfig.AvailConfigManger;
import com.jd.app.server.manager.discovery.live.concurrent.ConcurrentTask;
import com.jd.app.server.manager.discovery.live.concurrent.TaskContext;
import com.jd.app.server.manager.discovery.live.concurrent.TaskHolder;
import com.jd.app.server.manager.discovery.live.concurrent.TaskTypeEnum;
import com.jd.app.server.manager.discovery.price.SkuPriceManager;
import com.jd.app.server.manager.discovery.releaseBaseMsg.ReleaseBaseMsgManager;
import com.jd.app.server.manager.discovery.shop.FollowShopManager;
import com.jd.app.server.manager.discovery.shop.ShopInfoManager;
import com.jd.app.server.manager.promotionhb.PromotionHbManager;
import com.jd.app.server.util.*;
import com.jd.gms.crs.enums.ProductBaseFieldEnum;
import com.jd.hmc.realtime.data.client.result.ActivityNumResult;
import com.jd.jim.cli.Cluster;
import com.jd.m.discovery.annotation.ChangeType;
import com.jd.m.discovery.commons.domain.author.AuthorBase;
import com.jd.m.discovery.enumerate.DiscoveryContentStyleEnum;
import com.jd.m.soa.shop.domain.jsf.ShopInfos;
import com.jd.vd.api.bean.VideoMarkResult;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author wuchuanquan
 * @date 2019/6/13 14:10
 */
@Service("promotionHbDetailListTaskHolder")
public class PromotionHbDetailListTaskHolder implements TaskHolder, PromotionHbDetailListTask, InitializingBean {
    private final Logger logger = LoggerFactory.getLogger(PromotionHbDetailListTaskHolder.class);

    @Autowired
    private Cluster followRelRedisClient;

    @Autowired
    private FollowShopManager followShopManager;

    @Autowired
    private PromotionHbManager promotionHbManager;

    @Autowired
    private ShopInfoManager shopInfoManager;

    @Autowired
    private ReleaseBaseMsgManager releaseBaseMsgManager;

    @Autowired
    private SkuPriceManager skuPriceManager;

    @Autowired
    private Cluster promotionHbClient;

    @Autowired
    private AvailConfigManger availConfigManager;

    private static List<String> shareTitleList = new ArrayList<String>() {{
        add("你的塑料好友已上线~求求你别来玩，现金奖励我一个人拿！");
        add("前方大红包出没！速来围观~看视频找答案，天天可领钱~");
        add("哈哈哈哈！这些题有毒，聪明人已经答对赚钱了，快来挑战我吧~");
    }};

    /**
     * 预处理
     */
    @Override
    @ConcurrentTask(taskType = TaskTypeEnum.BEFORE, order = 0)
    public boolean preHandle(TaskContext<PromotionHbDetailListContext> context) {
        Map<String, Object> bodyParam = context.getParams();
        String pin = context.getPin();
        String topId = MapUtils.getString(bodyParam, "topId", "");
        String referPageId = MapUtils.getString(bodyParam, "referPageId", "shipin");
        String offSet = MapUtils.getString(bodyParam, "OffSet", "");
        String refreshActivityId = MapUtils.getString(bodyParam, "refreshActivityId", "");

        PromotionHbDetailListContext pdlc = context.getContent();
        if (StringUtils.isEmpty(pin)) {
            pdlc.setHaveLogin(false);
            pdlc.setRiskControl(true);
        } else {
            pdlc.setHaveLogin(true);
            //风控检测 true 是正常用户，false 是风控用户
            if (promotionHbManager.riskControl(pin)) {
                pdlc.setRiskControl(true);
            } else {
                pdlc.setRiskControl(false);
            }
        }
        pdlc.setTopId(topId);
        pdlc.setReferPageId(referPageId);
        pdlc.setOffSet(offSet);
        pdlc.setRefreshActivityId(refreshActivityId);

        return true;
    }


    /**
     * 获取活动信息
     */
    @ConcurrentTask(taskType = TaskTypeEnum.BEFORE, order = 10)
    public boolean getValidActivityInfoList(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        List<PromotionHbActivityInfo> validActivityInfoList = pdlc.getValidActivityInfoList();
        List<PromotionHbActivityInfo> activityInfos = promotionHbManager.getAllValidPromotionHbActivityInfo();
        if (CollectionUtils.isNotEmpty(activityInfos)) {
            validActivityInfoList.addAll(activityInfos);
            Iterator<PromotionHbActivityInfo> iterator = activityInfos.iterator();
            Date now = new Date();
            logger.info("getValidActivityInfoList before:" + JSON.toJSONString(activityInfos));
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = new VideoHbDetailInfo();
                PromotionHbActivityInfo activityInfo = iterator.next();
                if (activityInfo != null && activityInfo.getActivityBeginTime().before(now) && activityInfo.getActivityEndTime().after(now)) {
                    videoHbDetailInfo.setPromotionHbActivityInfo(activityInfo);
                    try {
                        VideoHbDetailQuestionInfo questionInfo = JSON.parseObject(activityInfo.getActivityQuestion(), VideoHbDetailQuestionInfo.class);
                        questionInfo.setAnswer(null);
                        Collections.shuffle(questionInfo.getSelections());
                        videoHbDetailInfo.setQuestionInfo(questionInfo);
                    } catch (Exception e) {
                        logger.error("PromotionHbDetailListTaskHolder.getValidActivityInfoList", e);
                    }
                } else {
                    logger.info("getValidActivityInfoList continue:" + JSON.toJSONString(activityInfo));
                    continue;
                }
                videoHbDetailInfo.setActivityId(String.valueOf(activityInfo.getId()));
                videoHbDetailInfo.setStyle(activityInfo.getStyle());
                // 内容素材处理内容信息
                Long contentId = activityInfo.getContentId();
                Integer contentStyle = activityInfo.getContentStyle();
                if (contentId != null && contentId > 0 && contentStyle != null && (contentStyle == 11 || contentStyle == 2)) {
                    VideoHbDetailContentInfo videoHbDetailContentInfo = new VideoHbDetailContentInfo();
                    videoHbDetailContentInfo.setId(activityInfo.getContentId());
                    videoHbDetailContentInfo.setStyle(contentStyle);
                    videoHbDetailInfo.setContentInfo(videoHbDetailContentInfo);
                }
                //2019-07-19,新增banner需求：https://cf.jd.com/pages/viewpage.action?pageId=197879985
                if (StringUtils.isNotBlank(activityInfo.getBannerImgUrl()) &&
                        StringUtils.isNotBlank(activityInfo.getBannerBigBenefit()) &&
                        StringUtils.isNotBlank(activityInfo.getBannerSmallBenefit()) &&
                        StringUtils.isNotBlank(activityInfo.getBannerJumpH5Link())) {
                    HbBannerInfo bannerInfo = new HbBannerInfo();
                    bannerInfo.setBannerImgUrl(ClientPic.getImagePathCompletely(activityInfo.getBannerImgUrl()));
                    bannerInfo.setBannerBigBenefit(activityInfo.getBannerBigBenefit());
                    bannerInfo.setBannerSmallBenefit(activityInfo.getBannerSmallBenefit());
                    bannerInfo.setJump(JumpGenrator.getHbBannerJump(activityInfo.getBannerJumpH5Link()));
                    bannerInfo.setBannerSkuShowLevel(activityInfo.getBannerSkuShowLevel());
                    if (bannerInfo.getBannerSkuShowLevel() == null) {
                        bannerInfo.setBannerSkuShowLevel(PromotionHbConstants.DEFAULT_BANNER_SKU_SHOW_LEVEL);
                    }
                    videoHbDetailInfo.setHbBannerInfo(bannerInfo);
                }

                if (StringUtils.isEmpty(pdlc.getRefreshActivityId())) {
                    list.add(videoHbDetailInfo);
                } else if (pdlc.getRefreshActivityId().equalsIgnoreCase(videoHbDetailInfo.getActivityId())) {
                    list.add(videoHbDetailInfo);
                }
            }
        }
        return true;
    }

    /**
     * 通过版本筛选活动信息,只处理app，其他跳过
     */
    @ConcurrentTask(taskType = TaskTypeEnum.BEFORE, order = 100)
    public boolean filterVersionActivity(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        ClientInfo clientInfo = context.getClientInfo();
        if (!ClientVersionUtil.isPhoneApp(clientInfo)) {
            return true;
        }
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                    if (StringUtils.isNotEmpty(promotionHbActivityInfo.getVersionBegin()) && !ClientVersionUtil.leftLargerOrEqual(clientInfo.getClientVersion(), promotionHbActivityInfo.getVersionBegin())) {
                        iterator.remove();
                        continue;
                    }

                    if (StringUtils.isNotEmpty(promotionHbActivityInfo.getVersionEnd()) && ClientVersionUtil.leftLargerOrEqual(clientInfo.getClientVersion(), promotionHbActivityInfo.getVersionEnd())) {
                        iterator.remove();
                        continue;
                    }
                }
            }
        }
        return true;
    }

    ///////////////////////////////////////////////////////////////////////////

    /**
     * 分享信息
     */
    @ConcurrentTask
    public void getShareInfo(TaskContext<PromotionHbDetailListContext> context) {
        ShareInfo shareInfo = new ShareInfo();
        shareInfo.setTitle(shareTitleList.get(new Random().nextInt(3)));
        String shareTitile = availConfigManager.getAvailConfigStr(PromotionHbActivityConstant.USER_ACTIVITY_SHARE_TITLE, "");
        if (StringUtils.isNotEmpty(shareTitile)) {
            String[] shareTitleArray = shareTitile.split("\\|");
            if (null != shareTitleArray && shareTitleArray.length > 0) {
                shareInfo.setTitle(shareTitleArray[new Random().nextInt(shareTitleArray.length)]);
            }
        }
        shareInfo.setContent(availConfigManager.getAvailConfigStr(PromotionHbActivityConstant.USER_ACTIVITY_SHARE_CONTENT, "点击进入答题，立获红包"));
        String linkStr = promotionHbClient.get("promotionhb_detail_sharelink_key");
        if(StringUtils.isNotBlank(linkStr)){
            String[] linkStrArray = linkStr.split(";");
            Random random = new Random();
            int randomNumber = random.nextInt(linkStrArray.length);
            shareInfo.setUrl(linkStrArray[randomNumber]);
            logger.info("PromotionHbDetailListTaskHolder.getShareInfo.randomNumber:"+randomNumber+",linkStrArray:"+JSON.toJSONString(linkStrArray));
        }
        if(StringUtils.isBlank(shareInfo.getUrl())){
            shareInfo.setUrl(availConfigManager.getAvailConfigStr(PromotionHbActivityConstant.USER_ACTIVITY_SHARE_URL, "https://eco.m.jd.com/content/activity/poster/index.html"));
        }
        shareInfo.setAvatar(availConfigManager.getAvailConfigStr(PromotionHbActivityConstant.USER_ACTIVITY_SHARE_AVATAR, ClientPic.getImagePathCompletely("mobilecms/jfs/t1/75999/5/3047/45872/5d148376Edd0d8327/8e8f98a58618b517.jpg")));

        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    videoHbDetailInfo.setShareInfo(shareInfo);
                }
            }
        }
    }


    /**
     * 店铺信息
     */
    @ConcurrentTask
    public void getShopInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            boolean version = ClientVersionUtil.leftLargerOrEqual(context.getClientInfo().getClientVersion(), "8.2.0");

            //获取当前用户对所有店铺的关注状态
            Set<Long> shopIdSet = new HashSet<>();
            try {
                for (VideoHbDetailInfo tmp : list) {
                    String tmpShopId = tmp.getPromotionHbActivityInfo().getShopId();
                    if (StringUtils.isNotEmpty(tmpShopId) && StringUtils.isNumeric(tmpShopId)) {
                        shopIdSet.add(Long.parseLong(tmpShopId));
                    }
                }
            } catch (Exception e) {
                logger.error("PromotionHbDetailListTaskHolder.getShopInfo parse shopId error.", e);
            }
            Map<Long, Boolean> followStatusMap = followShopManager.getFollowShopStatus(context.getPin(), shopIdSet);

            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                    ShopInfoDIY shopInfoDIY;
                    String shopId = promotionHbActivityInfo.getShopId();
                    if (StringUtils.isNotEmpty(shopId) && StringUtils.isNumeric(shopId)) {
                        try {
                            ShopInfos shopInfo = shopInfoManager.getShopInfoByShopId(Long.parseLong(shopId));
                            if (null != shopInfo) {
                                shopInfoDIY = new ShopInfoDIY(shopId,
                                        shopInfo.getShopName(),
                                        "",
                                        String.valueOf(shopInfo.getVenderId()));
                                if (version || "youhui".equalsIgnoreCase(pdlc.getReferPageId())) {//优惠小程序也下发后台配置的图片
                                    if (StringUtils.isNotEmpty(promotionHbActivityInfo.getShopPic())) {
                                        shopInfoDIY.setLogo(ClientPic.getImagePathCompletely(promotionHbActivityInfo.getShopPic()));
                                    }
                                } else {
                                    shopInfoDIY.setLogo(ClientPic.getImagePathCompletely(shopInfo.getLogoUrl()));
                                }

                                Boolean hasFollow = followStatusMap.get(Long.parseLong(shopId));
                                if (null != hasFollow && hasFollow) {
                                    shopInfoDIY.setHasFollow(1);
                                }
                                shopInfoDIY.setJump(JumpGenrator.SHOP.generater(shopInfoDIY));

                            } else {
                                logger.error("PromotionHbDetailListTaskHolder.getShopInfo query shopInfo error, shopId = " + shopId);
                                shopInfoDIY = new ShopInfoDIY("", "", "", "");
                            }
                        } catch (Exception e) {
                            logger.error("PromotionHbDetailListTaskHolder.getShopInfo exception. ", e);
                            shopInfoDIY = new ShopInfoDIY("", "", "", "");
                        }
                    } else {
                        shopInfoDIY = new ShopInfoDIY("", promotionHbActivityInfo.getShopName(), ClientPic.getImagePathCompletely(promotionHbActivityInfo.getShopLogo()), "");
                    }

                    videoHbDetailInfo.setShopInfo(shopInfoDIY);
                }
            }
        }
    }

    /**
     * 达人信息
     */
    @ConcurrentTask
    public void getAuthorInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            // 获取当前用户已关注的所有达人
            Set<String> hasFollowedSet = new HashSet<>();
            if (StringUtils.isNotEmpty(context.getPin())) {
                hasFollowedSet = followRelRedisClient.zRange(ChangeType.FOLLOW_REL_UPDATE.getRedisKey() + context.getPin(), 0, -1);
            }

            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                    String authorId = promotionHbActivityInfo.getAuthorId();
                    if (StringUtils.isNotEmpty(authorId)) {
                        AuthorBase authorBase = releaseBaseMsgManager.getAuthorBaseMsg(authorId, AuthorBase.class);
                        if (null != authorBase) {
                            AuthorInfoDIY authorInfoDIY = new AuthorInfoDIY(authorId, authorBase.getName(), "");
                            if (StringUtils.isNotEmpty(authorBase.getPic())) {
                                authorInfoDIY.setAuthorPic(ClientPic.getImagePathCompletely(authorBase.getPic()));
                            }
                            if (hasFollowedSet.contains(authorId)) {
                                authorInfoDIY.setHasFollow(1);
                            }
                            authorInfoDIY.setJump(JumpGenrator.getAuthorJump(authorId, "0"));
                            videoHbDetailInfo.setAuthorInfo(authorInfoDIY);
                        }
                    }

                }
            }
        }
    }

    /**
     * vid获取视频信息
     */
    @ConcurrentTask
    public void getVideoPlayInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        Set<String> vidSet = new HashSet<>();
        Map<String, VideoHbDetailPlayInfo> vidPlayInfoMap = new HashMap<>();
        if (list != null && list.size() > 0) {
            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                    if (null != promotionHbActivityInfo && StringUtils.isNotEmpty(promotionHbActivityInfo.getVid())) {
                        vidSet.add(promotionHbActivityInfo.getVid());
                    }
                }
            }
        }

        String videoType = VideoTencentUtils.getArticleVideoType(DiscoveryContentStyleEnum.VERT_VIDEO.getStyle());
        Map<String, VideoMarkResult> videoMarkResultMap = VideoTencentUtils.batchGetVideoMarkResultByVidSet(vidSet, videoType, VideoTencentUtils.LIVE_SHARPNESS_HIGH, context.getPin());
        Iterator<String> vidIter = vidSet.iterator();
        while (vidIter.hasNext()) {
            String vid = vidIter.next();
            VideoMarkResult videoMarkResult = videoMarkResultMap.get(vid);
            if (null != videoMarkResult) {
                VideoHbDetailPlayInfo playInfo = new VideoHbDetailPlayInfo(ClientVersionUtil.coverProtocol(videoMarkResult.getPlayUrl()),
                        videoMarkResult.getDuration(), videoType, videoMarkResult.getImageUrl(), vid);
                vidPlayInfoMap.put(vid, playInfo);
            }
        }

        for (VideoHbDetailInfo videoHbDetailInfo : list) {
            PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
            if (null != promotionHbActivityInfo && StringUtils.isNotEmpty(promotionHbActivityInfo.getVid())) {
                VideoHbDetailPlayInfo playInfo = vidPlayInfoMap.get(promotionHbActivityInfo.getVid());
                if (null != playInfo) {
                    if (StringUtils.isNotEmpty(promotionHbActivityInfo.getIndexImage())) {
                        playInfo.setVideoImg(ClientPic.getImagePathCompletely(promotionHbActivityInfo.getIndexImage()));
                    }
                    videoHbDetailInfo.setPlayInfo(playInfo);
                }


            }
        }
    }

    /**
     * 获取推荐sku信息
     */
    @ConcurrentTask
    public void getVideoSkuInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        Set<String> skuSet = new LinkedHashSet<>();

        Map<String, VideoHbDetailSkuVo> videoHbDetailSkuMap = new HashMap<>();
        if (list != null && list.size() > 0) {
            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                    if (null != promotionHbActivityInfo && StringUtils.isNotEmpty(promotionHbActivityInfo.getActivitySkus())) {
                        List<String> skuIds = Arrays.asList(promotionHbActivityInfo.getActivitySkus().split(",|，|；|;"));
                        videoHbDetailInfo.setSkuIds(skuIds);
                        skuSet.addAll(skuIds);
                    }
                }
            }
        }

        Map<String, Map<String, String>> priceResultMap = skuPriceManager.getPriceInfoMapBySKUIds(skuSet, context.getPin(), null);

        Map<String, Map<String, String>> skuResultMap = promotionHbManager.getVideoSkuInfoMult(skuSet);

//        Map<String, Map<String, String>> skuResultMap = promotionHbManager.getVideoSkuInfo(skuSet);


        logger.info("priceResultMap:" + JSON.toJSONString(priceResultMap));
        logger.info("skuResultMap:" + JSON.toJSONString(skuResultMap));
        for (String skuId : skuSet) {
            VideoHbDetailSkuVo videoHbDetailSkuVo = new VideoHbDetailSkuVo();
            Map<String, String> skuPriceMap = priceResultMap.get(skuId);
            Map<String, String> skuInfoMap = skuResultMap.get(skuId);
            if (null == skuPriceMap || null == skuInfoMap) {
                logger.info("continue:");
                continue;
            }

            String p = skuPriceMap.get("p");
            String m = skuPriceMap.get("m");
            String line = skuPriceMap.get("line");
            String img = skuInfoMap.get(ProductBaseFieldEnum.IMAGE_PATH.getField());
            String name = skuInfoMap.get(ProductBaseFieldEnum.NAME.getField());
            String isDelete = skuInfoMap.get(ProductBaseFieldEnum.IS_DELELTE.getField());
            String state = skuInfoMap.get(ProductBaseFieldEnum.STATE.getField());

            if (!"1".equalsIgnoreCase(isDelete) || !"1".equalsIgnoreCase(state)) {
                logger.error("PromotionHbDetailListTaskHolder.getVideoSkuInfo,商品状态异常:" + JSON.toJSONString(skuInfoMap));
                continue;
            }

            try {
                videoHbDetailSkuVo.setSku(skuId);
                videoHbDetailSkuVo.setPrice(null != p && !"-1".equalsIgnoreCase(p) && !"-1.00".equalsIgnoreCase(p) ? PriceUtil.priceConvert(p) : "");
                videoHbDetailSkuVo.setMarketPrice(null != line && !"-1".equalsIgnoreCase(line) && !"-1.00".equalsIgnoreCase(line) ? PriceUtil.priceConvert(line) : "");
                if (StringUtils.isEmpty(videoHbDetailSkuVo.getMarketPrice())) {
                    videoHbDetailSkuVo.setMarketPrice(null != m && !"-1".equalsIgnoreCase(m) && !"-1.00".equalsIgnoreCase(m) ? PriceUtil.priceConvert(m) : "");
                }
                if (!availConfigManager.getAvailConfigBool("disc_promotion_hb_market_price_show", true)) {
                    videoHbDetailSkuVo.setMarketPrice("");
                }
                videoHbDetailSkuVo.setImg(ClientPic.getImagePathCompleteWithMobileCms(img));
                videoHbDetailSkuVo.setTitle(name);
                videoHbDetailSkuVo.setJump(JumpGenrator.getSkuDetailJump(skuId));
                logger.info("videoHbDetailSkuVo:" + JSON.toJSONString(videoHbDetailSkuVo));
                if (StringUtils.isNotEmpty(videoHbDetailSkuVo.getPrice())) {
                    videoHbDetailSkuMap.put(skuId, videoHbDetailSkuVo);
                }
            } catch (Exception e) {
                logger.error("PromotionHbDetailListTaskHolder.getVideoSkuInfo", e);
            }
        }


        for (VideoHbDetailInfo videoHbDetailInfo : list) {
            PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
            if (null != promotionHbActivityInfo && StringUtils.isNotEmpty(promotionHbActivityInfo.getActivitySkus())) {
                List<String> skuIds = videoHbDetailInfo.getSkuIds();
                for (String skuId : skuIds) {
                    VideoHbDetailSkuVo videoHbDetailSkuVo = videoHbDetailSkuMap.get(skuId);
                    if (null != videoHbDetailSkuVo) {
                        videoHbDetailInfo.getSkuList().add(videoHbDetailSkuVo);
                    }
                }

            }
        }
    }

    /**
     * 红包信息信息
     */
    @Override
    @ConcurrentTask
    public void getHongbaoInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                    if (null != promotionHbActivityInfo && StringUtils.isNotEmpty(promotionHbActivityInfo.getAwardId())) {
                        ActivityNumResult activityNumResult = promotionHbManager.refreshHongBaoStockResult(promotionHbActivityInfo.getAwardId());
                        VideoHbDetailHongbaoInfo hongbaoInfo = new VideoHbDetailHongbaoInfo();
                        if (availConfigManager.getAvailConfigBool("disc_promotion_hb_hongbao_single_show", true)) {
                            hongbaoInfo.setHbAmount(promotionHbActivityInfo.getHongbaoSingle());
                        } else {
                            hongbaoInfo.setHbAmount("");
                        }

                        if (null != activityNumResult && activityNumResult.getActivityCount() > activityNumResult.getNowCount()) {
                            hongbaoInfo.setHbStock(activityNumResult.getActivityCount() - activityNumResult.getNowCount());
                            // 预留2%
                            if (((hongbaoInfo.getHbStock() * 1.00f / activityNumResult.getActivityCount()) * 100) < availConfigManager.getAvailConfigInt(PromotionHbActivityConstant.PROMOTION_HB_RESERVED_STOCK, 2)) {
                                hongbaoInfo.setHbStock(0L);
                            }
                        } else {
                            hongbaoInfo.setHbStock(0L);
                        }

                        // 下线的处理为无库存
                        if (promotionHbActivityInfo.getUpDownStatus() == 0) {
                            hongbaoInfo.setHbStock(0L);
                        }

                        videoHbDetailInfo.setHongbaoInfo(hongbaoInfo);
                    }

                }
            }
        }
    }

    /**
     * 用户答题信息
     */
    @ConcurrentTask
    public void getAnswerInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        if (!pdlc.isHaveLogin()) {
            return;
        }
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo != null) {
                    PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                    if (null != promotionHbActivityInfo) {
                        try {
                            AnswerUserInfo userInfo = promotionHbManager.getAnswerUserInfo(context.getPin(), String.valueOf(promotionHbActivityInfo.getId()));
                            if (null != userInfo) {
                                VideoHbDetailAnswerInfo answerInfo = videoHbDetailInfo.getAnswerInfo();
                                answerInfo.setAdditionalCount(userInfo.getAdditionalCount());
                                answerInfo.setAnswerCount(userInfo.getAnswerCount());
                                answerInfo.setAnswerHbAmount(userInfo.getHbAmount() != null && userInfo.getHbAmount() > 0.000f ? String.valueOf(userInfo.getHbAmount()) : "");
                                answerInfo.setAnswerResult(userInfo.getAnswerResult());
                                answerInfo.setAnswerSelectionId(userInfo.getAnswerSelect());
                            }
                        } catch (Exception e) {
                            logger.error("PromotionHbDetailListTaskHolder.getAnswerInfo", e);
                        }
                    }
                }
            }
        }
    }

    /**
     * 获取小会场sku信息
     */
    @ConcurrentTask
    public void getActivitySecondSkuList(TaskContext<PromotionHbDetailListContext> context) {
        try {
            PromotionHbDetailListContext pdlc = context.getContent();
            List<VideoHbDetailInfo> list = pdlc.getList();
            Set<String> skuSet = new LinkedHashSet<>();
            Map<String, VideoHbDetailSkuVo> videoHbDetailSkuMap = new HashMap<>();
            Map<String,List<String>> activitySecondSkuMap = new HashMap<>();//key为活动ID，value为该活动下所有小会场sku信息
            if (list != null && list.size() > 0) {
                Iterator<VideoHbDetailInfo> iterator = list.iterator();
                while (iterator.hasNext()) {
                    VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                    if (videoHbDetailInfo != null) {
                        PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                        if (null != promotionHbActivityInfo && StringUtils.isNotEmpty(promotionHbActivityInfo.getActivitySecondSkus())) {
                            List<String> skuIds = Arrays.asList(promotionHbActivityInfo.getActivitySecondSkus().split(",|，|；|;"));
                            skuSet.addAll(skuIds);
                            activitySecondSkuMap.put(videoHbDetailInfo.getActivityId(),skuIds);
                        }
                    }
                }
            }

            Map<String, Map<String, String>> priceResultMap = skuPriceManager.getPriceInfoMapBySKUIds(skuSet, context.getPin(), null);
            Map<String, Map<String, String>> skuResultMap = promotionHbManager.getVideoSkuInfoMult(skuSet);
            logger.info("getActivitySecondSkuList.priceResultMap:" + JSON.toJSONString(priceResultMap));
            logger.info("getActivitySecondSkuList.skuResultMap:" + JSON.toJSONString(skuResultMap));
            for (String skuId : skuSet) {
                VideoHbDetailSkuVo videoHbDetailSkuVo = new VideoHbDetailSkuVo();
                Map<String, String> skuPriceMap = priceResultMap.get(skuId);
                Map<String, String> skuInfoMap = skuResultMap.get(skuId);
                if (null == skuPriceMap || null == skuInfoMap) {
                    logger.info("getActivitySecondSkuList.continue:"+skuId);
                    continue;
                }

                String p = skuPriceMap.get("p");
                String m = skuPriceMap.get("m");
                String line = skuPriceMap.get("line");
                String img = skuInfoMap.get(ProductBaseFieldEnum.IMAGE_PATH.getField());
                String name = skuInfoMap.get(ProductBaseFieldEnum.NAME.getField());
                String isDelete = skuInfoMap.get(ProductBaseFieldEnum.IS_DELELTE.getField());
                String state = skuInfoMap.get(ProductBaseFieldEnum.STATE.getField());

                if (!"1".equalsIgnoreCase(isDelete) || !"1".equalsIgnoreCase(state)) {
                    logger.error("PromotionHbDetailListTaskHolder.getActivitySecondSkuList.getVideoSkuInfo,商品状态异常:" + JSON.toJSONString(skuInfoMap)+",skuId:"+skuId);
                    continue;
                }

                try {
                    videoHbDetailSkuVo.setSku(skuId);
                    videoHbDetailSkuVo.setPrice(null != p && !"-1".equalsIgnoreCase(p) && !"-1.00".equalsIgnoreCase(p) ? PriceUtil.priceConvert(p) : "");
                    videoHbDetailSkuVo.setMarketPrice(null != line && !"-1".equalsIgnoreCase(line) && !"-1.00".equalsIgnoreCase(line) ? PriceUtil.priceConvert(line) : "");
                    if (StringUtils.isEmpty(videoHbDetailSkuVo.getMarketPrice())) {
                        videoHbDetailSkuVo.setMarketPrice(null != m && !"-1".equalsIgnoreCase(m) && !"-1.00".equalsIgnoreCase(m) ? PriceUtil.priceConvert(m) : "");
                    }
                    if (!availConfigManager.getAvailConfigBool(VideoBusinessSwitchEnums.VIDEO_PROMOTION_HB_ACTIVITY_SECOND_SKUS_MARKET_PRICE_SHOW.getKey(), (boolean)VideoBusinessSwitchEnums.VIDEO_PROMOTION_HB_ACTIVITY_SECOND_SKUS_MARKET_PRICE_SHOW.getDefaultValue())) {
                        videoHbDetailSkuVo.setMarketPrice("");
                    }
                    videoHbDetailSkuVo.setImg(ClientPic.getImagePathCompleteWithMobileCms(img));
                    videoHbDetailSkuVo.setTitle(name);
                    videoHbDetailSkuVo.setJump(JumpGenrator.getSkuDetailJump(skuId));
                    logger.info("getActivitySecondSkuList.videoHbDetailSkuVo:" + JSON.toJSONString(videoHbDetailSkuVo));
                    if (StringUtils.isNotEmpty(videoHbDetailSkuVo.getPrice())) {
                        videoHbDetailSkuMap.put(skuId, videoHbDetailSkuVo);
                    }
                } catch (Exception e) {
                    logger.error("PromotionHbDetailListTaskHolder.getActivitySecondSkuList.getVideoSkuInfo,skuId:"+skuId, e);
                }
            }

            for (VideoHbDetailInfo videoHbDetailInfo : list) {
                PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                if (null != promotionHbActivityInfo && StringUtils.isNotEmpty(promotionHbActivityInfo.getActivitySecondSkus())) {
                    //设置促销logo
                    if (StringUtils.isNotEmpty(promotionHbActivityInfo.getPromotionLogo())){
                        videoHbDetailInfo.setSecondSkuMainLogo(ClientPic.getImagePathCompletely(promotionHbActivityInfo.getPromotionLogo()));
                    }
                    List<String> skuList = activitySecondSkuMap.get(videoHbDetailInfo.getActivityId());
                    if(CollectionUtils.isNotEmpty(skuList)){
                        for (String skuId :skuList ) {
                            VideoHbDetailSkuVo videoHbDetailSkuVo = videoHbDetailSkuMap.get(skuId);
                            if (null != videoHbDetailSkuVo) {
                                videoHbDetailInfo.getActivitySecondSkuList().add(videoHbDetailSkuVo);
                            }
                        }
                    }
                }
            }

            //注释掉切量
            //Map<String,Object> op = availConfigManager.getAvailConfigJson(VideoBusinessSwitchEnums.VIDEO_PROMOTION_HB_ACTIVITY_SECOND_SKUS_SWITCH.getKey(),JsonUtils.json2Map((String)VideoBusinessSwitchEnums.VIDEO_PROMOTION_HB_ACTIVITY_SECOND_SKUS_SWITCH.getDefaultValue()));
            //if(op!=null && (boolean)op.get("open") && op.get("range")!=null){
                //表示打开切量，计算切量范围值
                //int clientRate = DeviceIdUtil.calculateRate(context.getClientInfo());
                //Integer range = (Integer) op.get("range");//配置的切量范围
                //if(clientRate>=0 && clientRate<=range.intValue()){
                    //pdlc.setSecondSkuOpenState(true);
                    //切量范围0-19
                //}else{
                //    logger.info("PromotionHbDetailListTaskHolder.getActivitySecondSkuList切量值clientRate:"+clientRate+",配置值range:"+range);
                //}
            //}else{
            //    logger.info("PromotionHbDetailListTaskHolder.getActivitySecondSkuList切量开关关闭,op值"+JSON.toJSONString(op));
            //}
        } catch (Exception e) {
            logger.error("PromotionHbDetailListTaskHolder.getActivitySecondSkuList执行异常",e);
        }
    }
    /////////////////////////////////////////////////////////////////////////////

    /**
     * 数据校验过滤
     */
    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 0)
    public void filterInvalidActivity(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            Iterator<VideoHbDetailInfo> iterator = list.iterator();
            while (iterator.hasNext()) {
                VideoHbDetailInfo videoHbDetailInfo = iterator.next();
                if (videoHbDetailInfo == null) {
                    iterator.remove();
                    continue;
                }

                if(videoHbDetailInfo.getAuthorInfo()==null){
                    //改动原因，新增了达人ID模式，店铺信息可以不要的
                    ShopInfoDIY shopInfo = videoHbDetailInfo.getShopInfo();
                    if (null == shopInfo || StringUtils.isEmpty(shopInfo.getName()) || StringUtils.isEmpty(shopInfo.getLogo())) {
                        logger.error("filterInvalidActivity:reason:shopInfo , videoHbDetailInfo:" + JSON.toJSONString(videoHbDetailInfo));
                        iterator.remove();
                        continue;
                    }
                }

                VideoHbDetailPlayInfo playInfo = videoHbDetailInfo.getPlayInfo();
                if (null == playInfo || StringUtils.isEmpty(playInfo.getVid())
                        || StringUtils.isEmpty(playInfo.getVideoUrl())
                        || StringUtils.isEmpty(playInfo.getVideoImg())) {
                    logger.error("filterInvalidActivity:reason:playInfo , videoHbDetailInfo:" + JSON.toJSONString(videoHbDetailInfo));
                    iterator.remove();
                    continue;
                }

                VideoHbDetailQuestionInfo questionInfo = videoHbDetailInfo.getQuestionInfo();
                if (null == questionInfo || StringUtils.isEmpty(questionInfo.getQuestion())
                        || CollectionUtils.isEmpty(questionInfo.getSelections())) {
                    logger.error("filterInvalidActivity:reason:questionInfo , videoHbDetailInfo:" + JSON.toJSONString(videoHbDetailInfo));
                    iterator.remove();
                    continue;
                }

//                VideoHbDetailHongbaoInfo hongbaoInfo = videoHbDetailInfo.getHongbaoInfo();
//                if (null == hongbaoInfo || StringUtils.isEmpty(hongbaoInfo.getHbAmount())) {
//                    logger.error("filterInvalidActivity:reason:hongbaoInfo , videoHbDetailInfo:" + JSON.toJSONString(videoHbDetailInfo));
//                    iterator.remove();
//                    continue;
//                }

                ShareInfo shareInfo = videoHbDetailInfo.getShareInfo();
                if (null == shareInfo || StringUtils.isEmpty(shareInfo.getUrl())
                        || StringUtils.isEmpty(shareInfo.getTitle())) {
                    logger.error("filterInvalidActivity:reason:shareInfo , videoHbDetailInfo:" + JSON.toJSONString(videoHbDetailInfo));
                    iterator.remove();
                    continue;
                }

                List<VideoHbDetailSkuVo> skuList = videoHbDetailInfo.getSkuList();
                Iterator<VideoHbDetailSkuVo> skuVoIterator = skuList.iterator();
                while (skuVoIterator.hasNext()) {
                    VideoHbDetailSkuVo skuVo = skuVoIterator.next();
                    if (StringUtils.isEmpty(skuVo.getImg()) || StringUtils.isEmpty(skuVo.getTitle()) || StringUtils.isEmpty(skuVo.getPrice()) || "暂无报价".equalsIgnoreCase(skuVo.getPrice())) {
                        skuVoIterator.remove();
                    }
                }
            }
        }
    }

    /**
     * 数据排序
     * 1）默认排序a：有剩余红包并且还有答题机会的视频＞已拿过奖励视频＞答错无答题机会红包＞无红包剩余视频
     * 2）默认排序b：优先消耗今天上线的场次红包消耗掉，红包面额大的＞红包面额小的
     * 3）默认排序c（有剩余红包并且还有答题机会的视频）：红包面额倒序，红包面额相等情况下活动开始时间越新的优先
     * 红包有无库存-是否答题-是否还有答题机会-红包面额
     * 已登录：
     * 有红包 && 未答题  sort 1
     * 有红包 && 已答题 && 答错1次 && 分享过 sort 10
     * 有红包 && 已答题 && 答错1次 && 未分享过 sort 100
     * 有红包 && 已答题 && 答对 sort 1000
     * 有红包 && 已答题 && 答错2次 sort 10000
     * 无红包 sort 100000
     * 未登录：
     * 有红包 sort 1
     * 无红包 sort 100000
     */
    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 10)
    public void sortValidActivity(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            for (VideoHbDetailInfo videoHbDetailInfo : list) {
                VideoHbDetailHongbaoInfo hongbaoInfo = videoHbDetailInfo.getHongbaoInfo();
                VideoHbDetailAnswerInfo answerInfo = videoHbDetailInfo.getAnswerInfo();
                PromotionHbActivityInfo promotionHbActivityInfo = videoHbDetailInfo.getPromotionHbActivityInfo();
                if (hongbaoInfo.getHbStock() > 0) {
                    if (!pdlc.isHaveLogin()) {
                        videoHbDetailInfo.setSort(1);
                    } else if (answerInfo.getAnswerCount() == 0) {
                        videoHbDetailInfo.setSort(1);
                    } else if (answerInfo.getAnswerCount() == 1 && answerInfo.getAnswerResult() == 0 && answerInfo.getAdditionalCount() == 1) {
                        videoHbDetailInfo.setSort(1);
                    } else if (answerInfo.getAnswerCount() == 1 && answerInfo.getAnswerResult() == 0 && answerInfo.getAdditionalCount() == 0) {
                        videoHbDetailInfo.setSort(100);
                    } else if (answerInfo.getAnswerResult() == 1) {
                        videoHbDetailInfo.setSort(1000);
                    } else if (answerInfo.getAnswerCount() == 2 && answerInfo.getAnswerResult() == 0) {
                        videoHbDetailInfo.setSort(10000);
                    } else {
                        videoHbDetailInfo.setSort(100000);
                    }
                } else {
                    videoHbDetailInfo.setSort(100000);
                }
                if (null != promotionHbActivityInfo && null != promotionHbActivityInfo.getActivityBeginTime()) {
                    if (promotionHbManager.isToday(promotionHbActivityInfo.getActivityBeginTime())) {
                        videoHbDetailInfo.setTimeSort(1);
                    } else {
                        videoHbDetailInfo.setTimeSort(10);
                    }

                } else {
                    videoHbDetailInfo.setTimeSort(100000);
                }

            }
            Collections.sort(list, new Comparator<VideoHbDetailInfo>() {
                @Override
                public int compare(VideoHbDetailInfo o1, VideoHbDetailInfo o2) {
                    if (o1.getSort().compareTo(o2.getSort()) == 0) {
                        if (o1.getTimeSort().compareTo(o2.getTimeSort()) == 0) {
                            Float hbAmount1 = StringUtils.isNoneBlank(o1.getHongbaoInfo().getHbAmount()) ?
                                    Float.parseFloat(o1.getHongbaoInfo().getHbAmount())
                                    : 0f;
                            Float hbAmount2 = StringUtils.isNoneBlank(o2.getHongbaoInfo().getHbAmount()) ?
                                    Float.parseFloat(o2.getHongbaoInfo().getHbAmount())
                                    : 0f;

                            if (hbAmount2.compareTo(hbAmount1) == 0) {
                                return o2.getPromotionHbActivityInfo().getActivityBeginTime().compareTo(o1.getPromotionHbActivityInfo().getActivityBeginTime());
                            } else {
                                return hbAmount2.compareTo(hbAmount1);
                            }
                        } else {
                            return o1.getTimeSort().compareTo(o2.getTimeSort());
                        }

                    } else {
                        return o1.getSort().compareTo(o2.getSort());
                    }
                }
            });

            //针对裂变置顶
            String topId =  pdlc.getTopId();
            if(StringUtils.isNotBlank(topId)){
                VideoHbDetailInfo videoHbDetailInfoIndex = null;
                int topIndex = 0;
                for(int i=0;i<list.size();i++){
                    VideoHbDetailHongbaoInfo hongbaoTop = list.get(i).getHongbaoInfo();
                    VideoHbDetailInfo detailInfoTop = list.get(i);
                    if(detailInfoTop!=null &&
                            hongbaoTop !=null &&
                            hongbaoTop.getHbStock()!=null &&
                            hongbaoTop.getHbStock().longValue()>0 &&
                            topId.equals(detailInfoTop.getActivityId())){
                        //定位到需要置顶的红包ID则，记录该位置
                        topIndex = i;
                        videoHbDetailInfoIndex = detailInfoTop;
                        break;
                    }
                }
                if(topIndex>0 && videoHbDetailInfoIndex!=null){
                    list.remove(topIndex);
                    list.add(0,videoHbDetailInfoIndex);
                }
            }
        }
    }

    /**
     * 活动信息全局配置等
     */
    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 100)
    public void getGlobalConfigInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        VideoHbDetailActivityInfo globalActivityInfo = new VideoHbDetailActivityInfo();
        GlobalConfigInfo globalConfigInfo = promotionHbManager.defaultConfigInfo();
        globalActivityInfo.setAnswerLimit(globalConfigInfo.getAnswerLimit());
        globalActivityInfo.setAllActivityOutTip(globalConfigInfo.getAllActivityOutTip());
        globalActivityInfo.setHaveWatchAllVideoTip(globalConfigInfo.getHaveWatchAllVideoTip());
        globalActivityInfo.setOutOfAnswerLimitTip(globalConfigInfo.getOutOfAnswerLimitTip());
        pdlc.setActivityInfo(globalActivityInfo);
    }

    @Override
    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 101)
    public void checkOutOfAnswerLimit(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        VideoHbDetailActivityInfo globalActivityInfo = pdlc.getActivityInfo();
        if (pdlc.isHaveLogin()) {
            int countDay = promotionHbManager.answerCountDay(context.getPin());
            if (countDay >= globalActivityInfo.getAnswerLimit()) {
                globalActivityInfo.setOutOfAnswerLimit(1);
            } else {
                globalActivityInfo.setOutOfAnswerLimit(0);
            }
        } else {
            globalActivityInfo.setOutOfAnswerLimit(0);
        }
    }

    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 102)
    public void checkAllActivityOut(TaskContext<PromotionHbDetailListContext> context) {

        PromotionHbDetailListContext pdlc = context.getContent();
        VideoHbDetailActivityInfo globalActivityInfo = pdlc.getActivityInfo();
        if (StringUtils.isNotEmpty(pdlc.getRefreshActivityId())) {
            return;
        }

        globalActivityInfo.setAllActivityOut(1);
        List<VideoHbDetailInfo> list = pdlc.getList();
        if (list != null && list.size() > 0) {
            for (VideoHbDetailInfo videoHbDetailInfo : list) {
                VideoHbDetailHongbaoInfo hongbaoInfo = videoHbDetailInfo.getHongbaoInfo();
                if (hongbaoInfo.getHbStock() > 0) {
                    globalActivityInfo.setAllActivityOut(0);
                    break;
                }
            }
        }
    }


    /**
     * 数据缓存
     */
    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 1000)
    public void cacheDetailList(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        String redisKey;

        if (StringUtils.isNotEmpty(pdlc.getRefreshActivityId())) {
            return;
        }

        if (pdlc.isHaveLogin()) {
            redisKey = Joiner.on("_").join(PromotionHbActivityConstant.USER_ACTIVITY_DETAIL_LIST_PREFIX, context.getPin());
        } else {
            String uuid = DeviceIdUtil.getDeviceId(context.getClientInfo());
            redisKey = Joiner.on("_").join(PromotionHbActivityConstant.USER_ACTIVITY_DETAIL_LIST_PREFIX, uuid);
        }
        promotionHbClient.setEx(redisKey, JSON.toJSONString(context, SerializerFeature.WriteClassName), 3, TimeUnit.HOURS);
    }


    /**
     * 数据组装
     */
    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 100000)
    public void afterHandle(TaskContext<PromotionHbDetailListContext> context) {
//        PromotionHbDetailListContext pdlc = context.getContent();
//        Result result = context.getResult();
//        ResultUtils.buildSuccessResult(result);
//        int pageSize = 5;
//        if (pdlc.getList().size() > pageSize) {
//            List<VideoHbDetailInfo> videoHbDetailInfoList = pdlc.getList().subList(0, pageSize);
//            pdlc.setList(videoHbDetailInfoList);
//            pdlc.setOffSet(pdlc.getList().get(pdlc.getList().size() - 1).getActivityId());
//        } else if (pdlc.getList().size() > 0) {
//            pdlc.setOffSet(pdlc.getList().get(pdlc.getList().size() - 1).getActivityId());
//        } else {
//            //没有有效数据
//        }
//
//        result.addDefaultModel("data", pdlc);

    }


    @ConcurrentTask(taskType = TaskTypeEnum.AFTER, order = 103)
    public void getHbCardPlayTimeRuleInfo(TaskContext<PromotionHbDetailListContext> context) {
        PromotionHbDetailListContext pdlc = context.getContent();
        HbCardPlayTimeRuleInfo playTimeRuleInfo = null;
        try {
            String result = availConfigManager.getAvailConfigStr(VideoHbConfigKeyConstants.VIDEO_HB_GLOBAL_CARD_PLAY_TIME_RULE);
            if(StringUtils.isNotBlank(result)){
                playTimeRuleInfo = JSON.parseObject(result,HbCardPlayTimeRuleInfo.class);
                logger.info("PromotionHbDetailListTaskHolder.getHbCardPlayTimeRuleInfo.playTimeRuleInfo:"+JSON.toJSONString(playTimeRuleInfo));
            }else{
                logger.error("PromotionHbDetailListTaskHolder.getHbCardPlayTimeRuleInfo获取不到卡片播放全局规则,参数信息:"+JSON.toJSONString(context.getParams())+"用户Pin:"+context.getPin());
            }
        } catch (Exception e) {
            logger.error("PromotionHbDetailListTaskHolder.getHbCardPlayTimeRuleInfo获取卡片播放全局规则异常,参数信息:" + JSON.toJSONString(context.getParams()) + "用户Pin:" + context.getPin(), e);
        }
        if (playTimeRuleInfo == null ||
                playTimeRuleInfo.getBannerButtonRedTime() == null ||
                playTimeRuleInfo.getCardPlayIntervalTime() == null) {
            playTimeRuleInfo = new HbCardPlayTimeRuleInfo();
            playTimeRuleInfo.setBannerButtonRedTime(PromotionHbConstants.DEFAULT_BANNER_BUTTON_RED_TIME);
            playTimeRuleInfo.setCardPlayIntervalTime(PromotionHbConstants.DEFAULT_CARD_PLAY_INTERVAL_TIME);
        }
        pdlc.setHbCardPlayTimeRuleInfo(playTimeRuleInfo);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void afterPropertiesSet() throws Exception {
        ParserConfig.getGlobalInstance().setAutoTypeSupport(true);
    }

}
