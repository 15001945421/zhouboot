package com.jd.app.server.manager.discovery.live.concurrent;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by zhouhonglin on 2019/1/15.
 */
@Target(value = ElementType.METHOD)
@Retention(value = RetentionPolicy.RUNTIME)
public @interface ConcurrentTask {
    public String umpKey() default "";
    public String availConfigKey() default "";
    public TaskTypeEnum  taskType() default TaskTypeEnum.CONCURRENT;
    public ClientEnum client() default ClientEnum.all;
    public String clientVersion()default "";//版本号 >=
    public String maxClientVersion() default "";//版本号 <
    public int order() default 0;
}
