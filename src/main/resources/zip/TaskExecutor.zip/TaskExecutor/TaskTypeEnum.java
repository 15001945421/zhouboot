package com.jd.app.server.manager.discovery.live.concurrent;

/**
 * Created by zhouhonglin on 2019/3/20.
 */
public enum TaskTypeEnum {
    BEFORE, //并发任务的前置任务，如果返回false，后面的任务不执行
    CONCURRENT, //可并发执行的任务
    AFTER; //并发任务的后置任务
}
